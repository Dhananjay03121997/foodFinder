'use client'

import { useColors } from '../hooks/useColors';
import { useMenuData } from '../hooks/useMenuData';
import Header from '../components/Header';
import MenuList from '../components/MenuList';
import { useEffect, useState } from 'react';

const tenantId = '66be4ba75cee6b284f4adff0';

export default function Home() {
  const { colors, loading: colorsLoading, error: colorsError } = useColors(tenantId);
  const { menuData, loading: menuLoading, error: menuError } = useMenuData(tenantId);
  const [selectedCategory, setSelectedCategory] = useState({ _id: 0, name: "all" });

  if (colorsLoading || menuLoading) return <div>Loading...</div>;
  if (colorsError || menuError) return <div>Error loading data</div>;


  return (
    <main style={{ backgroundColor: colors.mainColor, color: colors.textColor }}>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8">Cafe Menu</h1>
        <Header categories={menuData.categories} colors={colors} setCategory={setSelectedCategory} selectedCategory={selectedCategory} />
        {/* {[{ _id: 0, name: 'all' }, ...menuData.categories].map(category => (
          <button
            key={category.name}
            className={`px-4 py-2 rounded-full ${selectedCategory.name === category.name
              ? 'bg-opacity-100'
              : 'bg-opacity-50 hover:bg-opacity-75'
              }`}
            style={{
              backgroundColor: colors.subColor,
              color: colors.textColor,
            }}
            onClick={() => {
              console.log('category', category);
              setSelectedCategory(category)
            }}
          >
            {category.name.charAt(0).toUpperCase() + category.name.slice(1)}
          </button>
        ))} */}
        <MenuList products={menuData.products} colors={colors} selectedCategory={selectedCategory} />
      </div>
    </main>
  );
}
import { useEffect, useState } from 'react';

export default function Header({ categories, colors, setCategory, selectedCategory }) {
    const [allCategories, setallCategories] = useState(['all']);
    let category = [];
    console.log("categories", categories);
    useEffect(() => {
        category = ['all']
        categories.forEach(element => {
            category.push(element.name);
        });
        setallCategories(category);
    }, []);
    return (
        <header className="overflow-x-auto whitespace-nowrap pb-4">
            <div className="inline-flex space-x-4">
                {[{ _id: 0, name: 'all' }, ...categories].map(category => (
                    <button
                        key={category.name}
                        className={`px-4 py-2 rounded-full ${selectedCategory.name === category.name
                            ? 'bg-opacity-100'
                            : 'bg-opacity-50 hover:bg-opacity-75'
                            }`}
                        style={{
                            backgroundColor: colors.subColor,
                            color: colors.textColor,
                        }}
                        onClick={() => {
                            console.log('category', category);
                            setCategory(category)
                        }}
                    >
                        {category.name.charAt(0).toUpperCase() + category.name.slice(1)}
                    </button>
                ))}
            </div>
        </header>
    );
}
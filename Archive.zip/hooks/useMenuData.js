import { useState, useEffect } from 'react';

export function useMenuData(tenantId) {
    const [menuData, setMenuData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch(`http://localhost:1234/product?tenantId=${tenantId}`)
            .then(response => response.json())
            .then(data => {
                setMenuData(data.data);
                setLoading(false);
            })
            .catch(err => {
                setError(err);
                setLoading(false);
            });
    }, [tenantId]);

    return { menuData, loading, error };
}
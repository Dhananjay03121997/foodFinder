import { useState, useEffect } from 'react';

export function useColors(tenantId) {
    const [colors, setColors] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch(`http://localhost:1234/tenant?tenantId=${tenantId}`)
            .then(response => response.json())
            .then(data => {
                setColors(data);
                setLoading(false);
            })
            .catch(err => {
                setError(err);
                setLoading(false);
            });
    }, [tenantId]);

    return { colors, loading, error };
}